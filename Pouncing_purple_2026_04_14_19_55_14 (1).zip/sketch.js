function setup() {
  createCanvas(400, 400);
}

function colorLoop (value){
  if(value > 255){
   value = 0 
  }
}

function draw() {
  background(220);
  noStroke();
  colorMode(RGB, 255, 255, 255, 1);
  setCenter(200,200);
  let x = frameCount % 200;
  fill(255, 0 ,0);
  polarEllipses(x, 50, 50, x);
  fill(0, 255, 0);
  polarPolygon(floor(x/20), 0, 5);
  fill(0, 0, 255)
  polarTriangles(floor((x/20)), 20, 20);
}