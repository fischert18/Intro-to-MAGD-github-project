function setup() {
  createCanvas(400, 400);
  noLoop();
}

function amount(min, max){
  let number = random(min, max);
  print(`there are ${number} tokens`)
  return number;
}

function tokenX(x, y, angle){
  push();
  translate(x, y);
  rotate(angle);
  strokeWeight(0);
  scale(5);
  triangle(x, y, x+4, y+16, x+10, y+10);
  triangle (x+20, y, x+16, y+16, x+10, y+10);
  circle(x+10, y+16, 12)
  strokeWeight(0.2);
  line(x+7, y+16, x+13, y+14);
  line (x+7, y+14, x+13, y+16);
  fill (204, 51, 102);
  arc(x+10, y+17, 8, 8, 0, 180);
  pop();
}

function draw() {
  background(0);
  colorMode(RGB, 255, 255, 255, 1);
  angleMode (DEGREES)
  for(i=0; i<amount(50,100); i++){
  tokenX(random (height/5), random(width/5), random(-30, 30));
  }
}