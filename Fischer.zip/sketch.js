let y = 200
let r = 100
let g = 100
let b = 100

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  let x = frameCount % 400;
  frameRate(60);
  
  if (mouseIsPressed === true) {
    y += 5;
    if (y >360) {
      y = 360;
    }
  }
  else {
    y -= 5;
    if (y < 0) {
      y = 0;
    }
  }
  
  if (keyIsPressed === true) {
    if (key === 'r') {
      r += 1;
      if (r > 255) {
        r = 10;
      }
    }
    else if (key === 'g') {
      g += 1;
      if (g > 255) {
        g = 10;
      }
    }
    else if (key === 'b') {
      b += 1;
      if (b > 255){
        b = 10;
      }
    }
  }
  
  fill (r, g, b)
  
  for(let x_square = x-400; x_square >= -400 && x_square <= 400; x_square += 60) {
    square(x_square, y, 30);
  } 
}